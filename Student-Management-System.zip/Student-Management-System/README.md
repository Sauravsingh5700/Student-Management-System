# Student Management System

A console-based Java application developed as an internship project.

## Features
- Add student
- View all students
- Search student by ID
- Update student details
- Delete student
- Duplicate ID validation
- Input validation
- File-based data persistence

## Technologies
- Java
- Object-Oriented Programming
- Java Collections Framework
- File Handling
- Exception Handling

## Project Structure
```
Student-Management-System/
├── src/
│   ├── Main.java
│   ├── Student.java
│   └── StudentManager.java
├── README.md
└── students.dat (created automatically when data is saved)
```

## How to Run
1. Install JDK 17 or later.
2. Open the project folder in VS Code or IntelliJ IDEA.
3. Compile:
   `javac src/*.java`
4. Run:
   `java -cp src Main`

## Internship Details
- Intern: Saurav Singh
- Role: Java Developer Intern
- Organization: Codec Technologies
- Internship Duration: July 2026
